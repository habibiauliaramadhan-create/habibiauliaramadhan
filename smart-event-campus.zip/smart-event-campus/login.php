<?php
session_start();
require_once __DIR__ . '/config/db.php';

// Kalau sudah login, langsung lempar ke dashboard
if (!empty($_SESSION['admin_id'])) {
    header('Location: admin/dashboard.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username === '' || $password === '') {
        $error = 'Username dan password wajib diisi.';
    } else {
        $stmt = $pdo->prepare('SELECT id, username, password, full_name FROM admins WHERE username = ?');
        $stmt->execute([$username]);
        $admin = $stmt->fetch();

        if ($admin && password_verify($password, $admin['password'])) {
            session_regenerate_id(true);
            $_SESSION['admin_id']   = $admin['id'];
            $_SESSION['admin_name'] = $admin['full_name'];
            header('Location: admin/dashboard.php');
            exit;
        }

        $error = 'Username atau password salah.';
    }
}

$expired = isset($_GET['redirect']) && $_GET['redirect'] === 'expired';
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login Admin — Smart Event Campus</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<div class="topbar">
  <div class="container topbar-inner">
    <a href="index.php" class="brand">
      <span class="brand-mark zoomable"><img src="assets/img/logo-kampus.jpg" alt="Logo Smart Event Campus"></span>
      <span class="brand-text">
        <strong>Smart Event Campus</strong>
        <span>Portal Kegiatan Kampus</span>
      </span>
    </a>
    <nav>
      <a href="index.php">&larr; Kembali ke Katalog</a>
    </nav>
  </div>
</div>

<div class="auth-wrap">
  <div class="auth-card">
    <div class="brand-mark zoomable" style="width:56px;height:56px;">
      <img src="assets/img/logo-kampus.jpg" alt="Logo Smart Event Campus">
    </div>
    <h1>Login Administrator</h1>
    <p class="sub">Masuk untuk mengelola data kegiatan kampus.</p>

    <?php if ($expired): ?>
      <div class="alert alert-error">Sesi kamu berakhir atau kamu belum login. Silakan login terlebih dahulu.</div>
    <?php endif; ?>

    <?php if ($error): ?>
      <div class="alert alert-error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="post" action="login.php" novalidate>
      <div class="field">
        <label for="username">Username</label>
        <input type="text" id="username" name="username" autocomplete="username" required>
      </div>
      <div class="field">
        <label for="password">Password</label>
        <input type="password" id="password" name="password" autocomplete="current-password" required>
      </div>
      <button type="submit" class="btn btn-dark" style="width:100%; justify-content:center;">Masuk</button>
    </form>

    <p style="margin-top:18px; font-size:12px; color:var(--ink-soft); text-align:center;">
      Demo: <span class="mono">admin</span> / <span class="mono">admin123</span>
    </p>
  </div>
</div>

  <script src="assets/js/lightbox.js"></script>
</body>
</html>
