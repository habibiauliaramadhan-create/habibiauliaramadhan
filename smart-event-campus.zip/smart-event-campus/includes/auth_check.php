<?php
/**
 * Wajib di-include paling atas pada setiap halaman admin.
 * Menolak akses jika belum login.
 */
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['admin_id'])) {
    header('Location: ../login.php?redirect=expired');
    exit;
}
