<?php
/**
 * Konfigurasi koneksi database.
 * Sesuaikan DB_USER / DB_PASS jika kredensial MySQL XAMPP kamu berbeda.
 * Default XAMPP: user "root", password kosong.
 */
define('DB_HOST', 'localhost');
define('DB_NAME', 'smart_event_campus');
define('DB_USER', 'root');
define('DB_PASS', '');

try {
    $pdo = new PDO(
        "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $e) {
    die('Koneksi database gagal. Pastikan MySQL di XAMPP sudah berjalan dan database "smart_event_campus" sudah di-import. Detail: ' . $e->getMessage());
}
