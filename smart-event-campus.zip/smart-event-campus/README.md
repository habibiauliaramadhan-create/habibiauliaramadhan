# Smart Event Campus

Website pengelolaan kegiatan kampus (seminar, workshop, lomba, pelatihan) untuk tugas UTS mata kuliah **Pengembangan Web**. Dibangun dengan **PHP native + MySQL**, dijalankan di **XAMPP**.

## Fitur

- **Katalog publik** (`index.php`) — menampilkan semua event, bisa difilter per kategori.
- **Login admin** (`login.php`) — wajib login sebelum masuk ke menu pengelolaan.
- **CRUD event** (folder `admin/`) — tambah, lihat, ubah, hapus data event.
- Password admin disimpan ter-hash (bcrypt via `password_hash()`), bukan plain text.
- Session-based auth: setiap halaman admin dicek lewat `includes/auth_check.php`.
- Proteksi dasar: prepared statements (PDO) di semua query, `htmlspecialchars()` di semua output ke HTML.

## Struktur folder

```
smart-event-campus/
├── admin/
│   ├── dashboard.php      # daftar event + statistik
│   ├── add_event.php      # form tambah event
│   ├── edit_event.php     # form edit event
│   └── delete_event.php   # handler hapus event
├── assets/
│   └── css/style.css      # semua styling
├── config/
│   └── db.php             # koneksi database (PDO)
├── includes/
│   └── auth_check.php     # guard: tolak akses kalau belum login
├── sql/
│   └── smart_event_campus.sql   # struktur tabel + data contoh
├── index.php               # halaman publik (katalog event)
├── login.php
├── logout.php
└── README.md
```

## Cara Menjalankan di XAMPP

### 1. Salin project ke folder htdocs
Salin folder `smart-event-campus` ke dalam folder `htdocs` instalasi XAMPP kamu, misalnya:
- Windows: `C:\xampp\htdocs\smart-event-campus`
- macOS: `/Applications/XAMPP/htdocs/smart-event-campus`

### 2. Nyalakan Apache dan MySQL
Buka **XAMPP Control Panel**, klik **Start** pada modul **Apache** dan **MySQL**.

### 3. Buat database lewat phpMyAdmin
1. Buka browser, akses `http://localhost/phpmyadmin`
2. Klik menu **Import**
3. Pilih file `sql/smart_event_campus.sql` dari project ini
4. Klik **Go / Import**

Ini akan otomatis membuat database `smart_event_campus`, tabel `admins` dan `events`, beserta 1 akun admin default dan 4 contoh data event.

> Kalau kamu lebih suka cara manual: buka tab **SQL** di phpMyAdmin, copy-paste seluruh isi file `.sql` tersebut, lalu klik **Go**.

### 4. Cek koneksi database
Buka `config/db.php`. Untuk instalasi XAMPP default, biasanya **tidak perlu diubah** karena user MySQL default adalah `root` tanpa password:

```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'smart_event_campus');
define('DB_USER', 'root');
define('DB_PASS', '');
```

Kalau MySQL kamu punya password sendiri, sesuaikan `DB_PASS`.

### 5. Akses website
- Katalog publik: `http://localhost/smart-event-campus/index.php`
- Login admin: `http://localhost/smart-event-campus/login.php`

**Akun demo:**
- Username: `admin`
- Password: `admin123`

## Alur pengujian (untuk screenshot dokumentasi)

1. Buka `index.php` → pastikan daftar event tampil, coba klik filter kategori (Seminar/Workshop/Lomba/Pelatihan).
2. Klik **Login Admin** → coba login dengan password salah → pastikan muncul pesan error.
3. Login dengan akun demo yang benar → harus masuk ke `admin/dashboard.php`.
4. Coba akses langsung `admin/dashboard.php` di tab baru tanpa login (atau setelah logout) → harus otomatis diarahkan ke halaman login (bukti fitur keamanan bekerja).
5. Di dashboard, klik **+ Tambah Event** → isi form → simpan → pastikan data baru muncul di tabel dan juga muncul di katalog publik.
6. Klik **Edit** pada salah satu event → ubah data → simpan → pastikan perubahan tersimpan.
7. Klik **Hapus** pada salah satu event → konfirmasi → pastikan data hilang dari tabel dan katalog publik.
8. Klik **Keluar** (logout) → pastikan diarahkan ke halaman login dan tidak bisa lagi mengakses dashboard.

Setiap langkah di atas bagus untuk dijadikan 1 screenshot di dokumentasi PDF kamu.

## Catatan untuk laporan / dokumentasi

Kalau perlu dijadikan laporan PDF, screenshot yang wajib ada biasanya:
- Struktur database (tabel `admins` dan `events` di phpMyAdmin)
- Halaman katalog publik
- Halaman login (termasuk contoh error saat password salah)
- Halaman dashboard admin (list event)
- Form tambah/edit event
- Bukti percobaan akses tanpa login (redirect ke login)

## Kredensial default (ubah setelah testing)

| Username | Password |
|----------|----------|
| admin    | admin123 |

Password sudah di-hash dengan bcrypt di database, jadi aman untuk dikumpulkan meski file `.sql` ikut disertakan.
