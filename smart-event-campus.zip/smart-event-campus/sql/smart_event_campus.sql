-- =========================================================
-- Smart Event Campus - Database Schema
-- Import file ini lewat phpMyAdmin (XAMPP) sebelum
-- menjalankan aplikasi.
-- =========================================================

CREATE DATABASE IF NOT EXISTS smart_event_campus
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_general_ci;

USE smart_event_campus;

-- ---------------------------------------------------------
-- Tabel admins : akun administrator kampus
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  full_name VARCHAR(100) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Akun default -> username: admin | password: admin123
-- (password sudah di-hash dengan password_hash() PHP / bcrypt)
INSERT INTO admins (username, password, full_name) VALUES
('admin', '$2b$10$2O4uAPdOoSBD38YxmGuiJ.fe6k0FeBPstyvFbYJsngqTbp.VrIcSC', 'Administrator Kampus');

-- ---------------------------------------------------------
-- Tabel events : data kegiatan kampus
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS events (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(150) NOT NULL,
  category ENUM('Seminar','Workshop','Lomba','Pelatihan') NOT NULL,
  description TEXT NOT NULL,
  event_date DATE NOT NULL,
  event_time TIME NOT NULL,
  location VARCHAR(150) NOT NULL,
  quota INT NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Beberapa data contoh supaya tampilan awal tidak kosong
INSERT INTO events (title, category, description, event_date, event_time, location, quota) VALUES
('Seminar Nasional Kecerdasan Buatan', 'Seminar', 'Membahas perkembangan dan penerapan AI di berbagai industri bersama praktisi nasional.', '2026-08-14', '09:00:00', 'Aula Utama Kampus', 200),
('Workshop Pengembangan Web Modern', 'Workshop', 'Pelatihan hands-on membangun aplikasi web menggunakan PHP dan MySQL untuk mahasiswa Informatika.', '2026-08-20', '13:00:00', 'Lab Komputer 3', 40),
('Lomba Karya Tulis Ilmiah Mahasiswa', 'Lomba', 'Kompetisi karya tulis ilmiah tingkat universitas dengan tema inovasi digital.', '2026-09-02', '08:00:00', 'Gedung Rektorat Lt. 2', 60),
('Pelatihan Public Speaking', 'Pelatihan', 'Meningkatkan kepercayaan diri dan kemampuan berbicara di depan umum bagi mahasiswa baru.', '2026-08-28', '10:00:00', 'Ruang Serbaguna', 80);
