<?php
require_once __DIR__ . '/config/db.php';

$categories = ['Seminar', 'Workshop', 'Lomba', 'Pelatihan'];
$activeCategory = $_GET['kategori'] ?? '';

if (in_array($activeCategory, $categories, true)) {
    $stmt = $pdo->prepare('SELECT * FROM events WHERE category = ? ORDER BY event_date ASC');
    $stmt->execute([$activeCategory]);
} else {
    $stmt = $pdo->query('SELECT * FROM events ORDER BY event_date ASC');
}
$events = $stmt->fetchAll();

$pinClasses = ['Seminar' => 'pin-teal', 'Workshop' => 'pin-brass', 'Lomba' => 'pin-ink', 'Pelatihan' => 'pin-brass'];
$tagClasses = ['Seminar' => 'tag-seminar', 'Workshop' => 'tag-workshop', 'Lomba' => 'tag-lomba', 'Pelatihan' => 'tag-pelatihan'];

function formatTanggal(string $date): string {
    $bulan = ['01'=>'Jan','02'=>'Feb','03'=>'Mar','04'=>'Apr','05'=>'Mei','06'=>'Jun','07'=>'Jul','08'=>'Agu','09'=>'Sep','10'=>'Okt','11'=>'Nov','12'=>'Des'];
    [$y, $m, $d] = explode('-', $date);
    return ((int)$d) . ' ' . $bulan[$m] . ' ' . $y;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Smart Event Campus — Katalog Kegiatan Kampus</title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<div class="topbar">
  <div class="container topbar-inner">
    <a href="index.php" class="brand">
      <span class="brand-mark zoomable"><img src="assets/img/logo-kampus.jpg" alt="Logo Smart Event Campus"></span>
      <span class="brand-text">
        <strong>Smart Event Campus</strong>
        <span>Portal Kegiatan Kampus</span>
      </span>
    </a>
    <nav>
      <a href="#katalog">Katalog</a>
      <a href="login.php" class="btn-ghost-light">Login Admin</a>
    </nav>
  </div>
</div>

<header class="hero">
  <div class="container">
    <div class="eyebrow">Papan Pengumuman Digital</div>
    <h1>Semua kegiatan kampus, dalam satu papan.</h1>
    <p class="lead">Seminar, workshop, lomba, dan pelatihan mahasiswa — dicatat dan dikelola langsung oleh administrator kampus.</p>
  </div>
</header>

<main class="board" id="katalog">
  <div class="container">
    <div class="filters">
      <a href="index.php" class="<?= $activeCategory === '' ? 'active' : '' ?>">Semua</a>
      <?php foreach ($categories as $cat): ?>
        <a href="?kategori=<?= urlencode($cat) ?>" class="<?= $activeCategory === $cat ? 'active' : '' ?>"><?= $cat ?></a>
      <?php endforeach; ?>
    </div>

    <?php if (empty($events)): ?>
      <div class="empty-state" style="margin-top:24px;">
        <h3>Belum ada kegiatan</h3>
        <p>Belum ada agenda untuk kategori ini. Coba lihat kategori lain.</p>
      </div>
    <?php else: ?>
      <div class="event-grid" style="margin-top:24px;">
        <?php foreach ($events as $ev): ?>
          <article class="notice <?= $pinClasses[$ev['category']] ?? 'pin-ink' ?>">
            <span class="tag <?= $tagClasses[$ev['category']] ?? '' ?>"><?= htmlspecialchars($ev['category']) ?></span>
            <h3><?= htmlspecialchars($ev['title']) ?></h3>
            <p class="desc"><?= htmlspecialchars($ev['description']) ?></p>
            <div class="meta">
              <span><b>Tanggal:</b> <?= formatTanggal($ev['event_date']) ?>, <?= substr($ev['event_time'], 0, 5) ?> WIB</span>
              <span><b>Lokasi:</b> <?= htmlspecialchars($ev['location']) ?></span>
              <span><b>Kuota:</b> <?= (int)$ev['quota'] ?> peserta</span>
            </div>
          </article>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</main>

<footer>
  <div class="container">
    &copy; <?= date('Y') ?> Smart Event Campus — Universitas Potensi Utama
  </div>
</footer>

  <script src="assets/js/lightbox.js"></script>
</body>
</html>
